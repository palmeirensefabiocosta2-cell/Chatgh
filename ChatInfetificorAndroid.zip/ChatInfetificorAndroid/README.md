# ChatInfetificor Android

Projeto Android Studio que empacota o site ChatInfetificor em um aplicativo Android.

## O que foi integrado
- Botão de galeria usa `ACTION_PICK` com imagens, para abrir o seletor/galeria de imagens do Android (em aparelhos Samsung, normalmente encaminha ao app Galeria ou ao seletor configurado).
- Botão de câmera abre a câmera nativa e devolve a imagem ao site.
- A foto é carregada no preview já existente e segue para a análise do site.

## Como gerar o APK
1. Abra o Android Studio.
2. Escolha **Open** e selecione esta pasta `ChatInfetificorAndroid`.
3. Aguarde a sincronização do Gradle e a instalação dos componentes do Android SDK, se solicitados.
4. Vá em **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. O APK de teste ficará em `app/build/outputs/apk/debug/app-debug.apk`.

## Observações
- Este pacote é o projeto-fonte Android Studio, não um APK já compilado.
- A câmera usa a miniatura fornecida pela intent padrão do Android; a resolução pode ser menor que a câmera completa.
- A análise de imagem continua dependendo do código/modelo já presente no site e de conexão com a internet, quando aplicável.
- O seletor de fotos varia conforme a versão do Android e os aplicativos instalados; o sistema operacional decide qual tela de seleção será exibida.
