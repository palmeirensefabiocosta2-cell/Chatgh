package com.chatinfetificor.app

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import java.io.ByteArrayOutputStream

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private val galleryRequest = 4101
    private val cameraRequest = 4102

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        setContentView(webView)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.webViewClient = WebViewClient()
        webView.webChromeClient = WebChromeClient()
        webView.addJavascriptInterface(NativeBridge(), "ChatInfetificorAndroid")
        webView.loadUrl("file:///android_asset/index.html")
    }

    inner class NativeBridge {
        @JavascriptInterface
        fun openGallery() {
            runOnUiThread {
                val pick = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
                pick.type = "image/*"
                try {
                    startActivityForResult(pick, galleryRequest)
                } catch (_: Exception) {
                    val fallback = Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*" }
                    startActivityForResult(Intent.createChooser(fallback, "Escolher foto"), galleryRequest)
                }
            }
        }

        @JavascriptInterface
        fun openCamera() {
            runOnUiThread {
                val camera = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
                if (camera.resolveActivity(packageManager) != null) {
                    startActivityForResult(camera, cameraRequest)
                } else {
                    sendStatus("Câmera não encontrada neste aparelho.")
                }
            }
        }
    }

    @Deprecated("Deprecated in Android API, retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != Activity.RESULT_OK || data == null) return
        try {
            val bitmap = when (requestCode) {
                galleryRequest -> {
                    val uri: Uri = data.data ?: return
                    contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
                }
                cameraRequest -> data.extras?.get("data") as? Bitmap
                else -> null
            } ?: return
            val scaled = scaleDown(bitmap, 1600)
            val out = ByteArrayOutputStream()
            scaled.compress(Bitmap.CompressFormat.JPEG, 86, out)
            val encoded = Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
            val js = "window.onNativeAnimalImage && window.onNativeAnimalImage('data:image/jpeg;base64,$encoded','animal-photo.jpg');"
            webView.post { webView.evaluateJavascript(js, null) }
        } catch (_: Exception) {
            sendStatus("Não foi possível abrir essa imagem. Tente outra foto.")
        }
    }

    private fun scaleDown(source: Bitmap, maxSide: Int): Bitmap {
        val largest = maxOf(source.width, source.height)
        if (largest <= maxSide) return source
        val ratio = maxSide.toFloat() / largest.toFloat()
        return Bitmap.createScaledBitmap(source, (source.width * ratio).toInt(), (source.height * ratio).toInt(), true)
    }

    private fun sendStatus(message: String) {
        val safe = message.replace("'", "\\'")
        webView.post { webView.evaluateJavascript("if(window.setPhotoStatus) setPhotoStatus('$safe');", null) }
    }

    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}
